# 마리의 팡팡맨

크레이지 아케이드 / 봄버맨 스타일 물풍선 대전 게임 (PC 브라우저, 2~4인 멀티)

## 실행 방법

1. [Node.js](https://nodejs.org) 설치 (LTS 버전)
2. 이 폴더에서:
   ```
   npm install
   npm start
   ```
3. 브라우저에서 `http://localhost:3000` 접속 → 닉네임 입력 → **방 만들기**
4. 친구는 `http://<내 PC IP>:3000` 으로 접속 → 방 코드 입력 → **참가**
   - 같은 공유기(같은 와이파이)면 바로 됨. 내 IP 는 `cmd` → `ipconfig` 의 IPv4 주소
   - 혼자 테스트: 브라우저 창 2개를 열어서 하나는 방 만들기, 하나는 참가

조작: 방향키/WASD 이동, 스페이스 물풍선

## 구조

```
public/              ← 브라우저가 받는 파일
  config.js          ← 캐릭터 스탯·맵·규칙 (서버와 공유. 밸런스 조정은 여기만)
  index.html / style.css / client.js
server/
  server.js          ← 웹서버 + 웹소켓 + 방 관리 + 보안 장치
  game.js            ← 게임 규칙 시뮬레이션 (네트워크 없음)
  protocol.js        ← 클라이언트 메시지 검증
tests/
  game-test.js       ← 게임 규칙 테스트  (npm run test:game)
  security-test.js   ← 보안 테스트       (npm run test:security)
```

**권한형 서버**: 클라이언트는 "누르고 있는 방향"과 "물풍선 버튼"만 보내고,
위치·충돌·폭발·승패는 서버가 계산한다. 클라이언트를 조작해도 결과를 바꿀 수 없다.

## 캐릭터 그림 넣기

`public/assets/mari.png` 처럼 캐릭터 id 이름으로 PNG 를 넣고,
`config.js` 에서 해당 캐릭터의 `sprite: false` 를 `true` 로 바꾸면 된다.

## 보안 테스트

```
# 맥/리눅스
BAN_MS=5000 npm start                     # 터미널 1 (재접속 금지 시간을 짧게)
BAN_WAIT_MS=5500 npm run test:security    # 터미널 2

# 윈도우 PowerShell
$env:BAN_MS=5000; npm start
$env:BAN_WAIT_MS=5500; npm run test:security
```
(그냥 `npm start` / `npm run test:security` 로 돌려도 되지만, 중간에 61초 기다린다.)
결과는 `tests/security-report.json` 에도 저장된다.
**자기 서버에만 실행할 것.**

## 인터넷 공개 전에 해야 할 것

- HTTPS/WSS 적용 (Caddy 같은 리버스 프록시나 호스팅 서비스 사용)
- 프록시 뒤에 둘 경우, IP 제한이 프록시 IP 기준이 되지 않도록 `X-Forwarded-For` 처리 추가
- `ALLOWED_ORIGINS=https://내도메인` 환경변수 설정
