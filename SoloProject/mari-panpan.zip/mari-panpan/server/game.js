/* =====================================================================
 * game.js — 게임 한 판(라운드)의 "순수 시뮬레이션"
 * ---------------------------------------------------------------------
 * 네트워크 코드가 전혀 없는 파일. 입력(방향, 물풍선)을 받고
 * step(dt) 을 부를 때마다 세계를 dt 초만큼 진행시킨다.
 * → 네트워크 없이도 단위 테스트를 돌릴 수 있고,
 *   "모든 판정은 서버에서" 원칙(= 권한형 서버)을 지키는 핵심 부품이다.
 *
 * 좌표계: 타일 (i, j) 의 "중심"이 좌표 (i, j). 플레이어 x, y 는 실수.
 *         Math.round(x) 가 지금 서 있는 타일 번호.
 * ===================================================================== */
'use strict';

const { CHARACTERS, STAT_MAX, MAPS, RULES, ITEMS, TILE, speedToTilesPerSec } = require('../public/config.js');

// 방향 번호 → [dx, dy]. 0 = 정지. 프로토콜에서도 같은 번호를 쓴다.
const DIRS = [
  [0, 0],   // 0: 정지
  [0, -1],  // 1: 위
  [0, 1],   // 2: 아래
  [-1, 0],  // 3: 왼쪽
  [1, 0],   // 4: 오른쪽
];

// 플레이어 상태를 숫자로 보내기 위한 코드 (패킷 크기 절약)
const STATUS = { alive: 0, trapped: 1, dead: 2 };

class Game {
  /**
   * @param {string} mapId        config.js MAPS 의 키
   * @param {Array<{id:string, char:string}>} roster  참가자 목록 (입장 순서대로 스폰 배정)
   * @param {() => number} rng    난수 함수 (테스트에서 고정값을 넣을 수 있게 주입)
   */
  constructor(mapId, roster, rng = Math.random) {
    const map = MAPS[mapId];
    if (!map) throw new Error('unknown map');
    this.rng = rng;
    this.h = map.grid.length;
    this.w = map.grid[0].length;
    this.time = 0;                          // 라운드 시작 후 경과 시간(ms, 시뮬레이션 시계)
    this.tiles = new Uint8Array(this.w * this.h);
    this.items = new Map();                 // "x,y" → 아이템 번호
    this.bombs = [];                        // 설치된 물풍선 목록
    this.flames = new Map();                // "x,y" → 물줄기가 사라지는 시각
    this.tileChanges = [];                  // 이번 전송 이후 바뀐 타일 [x, y, 새값]
    this.players = new Map();
    this.over = false;
    this.winner = null;
    this.nextBombId = 1;

    // ---- 1) 맵 문자열 → 타일 배열, 스폰 위치 수집 ----
    const spawns = {};
    for (let y = 0; y < this.h; y++) {
      for (let x = 0; x < this.w; x++) {
        const ch = map.grid[y][x];
        let t = TILE.EMPTY;
        if (ch === '#') t = TILE.HARD;
        else if (ch === '?') t = rng() < map.softChance ? TILE.SOFT : TILE.EMPTY;
        else if (ch >= '1' && ch <= '4') spawns[ch] = { x, y };
        this.tiles[y * this.w + x] = t;
      }
    }

    // ---- 2) 플레이어 생성: 캐릭터 기본 스탯을 "복사"해서 가진다 ----
    //     (아이템을 먹으면 이 복사본만 올라가고 원본 설정은 그대로)
    roster.forEach((r, idx) => {
      const base = CHARACTERS[r.char];
      const sp = spawns[String(idx + 1)];
      this.players.set(r.id, {
        id: r.id,
        char: r.char,
        x: sp.x, y: sp.y,
        dir: 0,                    // 현재 누르고 있는 방향
        bombsMax: base.bombs,
        range: base.range,
        speed: base.speed,
        status: 'alive',
        trappedAt: 0,
      });
    });
  }

  // ------------------------------------------------------------------
  // 작은 도우미 함수들
  // ------------------------------------------------------------------
  key(x, y) { return x + ',' + y; }
  inBounds(x, y) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }
  tileAt(x, y) { return this.tiles[y * this.w + x]; }
  bombAt(x, y) { return this.bombs.find(b => b.x === x && b.y === y); }
  setTile(x, y, v) {
    this.tiles[y * this.w + x] = v;
    this.tileChanges.push([x, y, v]);       // 클라이언트에 "바뀐 칸"만 보내기 위해 기록
  }

  /** 플레이어 p 가 타일 (x, y) 에 들어갈 수 있는가? */
  canEnter(p, x, y) {
    if (!this.inBounds(x, y)) return false;
    if (this.tileAt(x, y) !== TILE.EMPTY) return false;
    const b = this.bombAt(x, y);
    // 물풍선 칸은 막혀 있다. 단, 설치 순간 그 칸에 겹쳐 있던 사람은 빠져나갈 수 있게 허용
    if (b && !b.passable.has(p.id)) return false;
    return true;
  }

  // ------------------------------------------------------------------
  // 입력 — 서버(server.js)가 검증을 마친 값만 여기로 들어온다
  // ------------------------------------------------------------------
  setInput(id, dir) {
    const p = this.players.get(id);
    if (p && p.status !== 'dead') p.dir = dir;
  }

  /** 물풍선 설치 요청. 조건이 안 맞으면 조용히 무시 (클라이언트 말을 믿지 않음) */
  placeBomb(id) {
    const p = this.players.get(id);
    if (!p || p.status !== 'alive' || this.over) return false;
    const bx = Math.round(p.x), by = Math.round(p.y);
    if (this.bombAt(bx, by)) return false;                                // 이미 그 칸에 있음
    const mine = this.bombs.filter(b => b.owner === id).length;
    if (mine >= p.bombsMax) return false;                                  // 개수 초과
    // 설치 순간 이 칸과 겹쳐 있는 모든 플레이어는 이 물풍선을 통과해 나갈 수 있다
    const passable = new Set();
    for (const q of this.players.values()) {
      if (q.status !== 'dead' && Math.abs(q.x - bx) < 1 && Math.abs(q.y - by) < 1) passable.add(q.id);
    }
    this.bombs.push({
      id: this.nextBombId++, x: bx, y: by, owner: id,
      range: p.range,                       // 설치 "당시"의 범위로 고정
      explodeAt: this.time + RULES.BOMB_FUSE_MS,
      passable,
    });
    return true;
  }

  // ------------------------------------------------------------------
  // 이동 — 봄버맨식 "길 맞춰 주기" 포함
  //   가로로 움직이면 세로 위치를 가장 가까운 칸 중심으로 먼저 맞춘다.
  //   그래서 살짝 어긋나 있어도 골목으로 자연스럽게 미끄러져 들어간다.
  // ------------------------------------------------------------------
  movePlayer(p, dt) {
    if (p.dir === 0 || p.status === 'dead') return;
    const [dx, dy] = DIRS[p.dir];
    const speed = p.status === 'trapped' ? RULES.TRAP_SPEED : speedToTilesPerSec(p.speed);
    let step = speed * dt;

    const main = dx !== 0 ? 'x' : 'y';      // 진행 축
    const perp = dx !== 0 ? 'y' : 'x';      // 수직 축
    const sign = dx !== 0 ? dx : dy;        // +1 / -1

    const cMain = Math.round(p[main]);
    const cPerp = Math.round(p[perp]);

    // 1) 수직 축 정렬: 칸 중심에서 벗어난 만큼 먼저 당겨 준다
    const off = p[perp] - cPerp;
    if (Math.abs(off) > 1e-6) {
      const a = Math.min(step, Math.abs(off));
      p[perp] -= Math.sign(off) * a;
      step -= a;
    }
    if (step <= 0) return;

    // 2) 진행 축 이동: 앞 칸이 열려 있으면 전진, 막혀 있으면 현재 칸 중심까지만
    const nx = main === 'x' ? cMain + sign : cPerp;
    const ny = main === 'y' ? cMain + sign : cPerp;
    if (this.canEnter(p, nx, ny)) {
      p[main] += sign * step;
    } else {
      const toCenter = cMain - p[main];     // 현재 칸 중심까지 남은 거리 (부호 포함)
      if (toCenter * sign > 0) p[main] += sign * Math.min(step, Math.abs(toCenter));
    }
  }

  // ------------------------------------------------------------------
  // 폭발 처리 — 연쇄 폭발은 큐(queue)로 처리
  // ------------------------------------------------------------------
  explode(first) {
    const queue = [first];
    const spawnedItems = [];                // 이번 폭발로 부서진 상자에서 나올 아이템 (폭발 후에 배치)
    const until = this.time + RULES.FLAME_MS;

    while (queue.length) {
      const b = queue.shift();
      const idx = this.bombs.indexOf(b);
      if (idx === -1) continue;             // 이미 처리됨
      this.bombs.splice(idx, 1);
      this.addFlame(b.x, b.y, until);

      for (let d = 1; d <= 4; d++) {
        const [dx, dy] = DIRS[d];
        for (let i = 1; i <= b.range; i++) {
          const x = b.x + dx * i, y = b.y + dy * i;
          if (!this.inBounds(x, y)) break;
          const t = this.tileAt(x, y);
          if (t === TILE.HARD) break;                         // 단단한 블록: 여기서 멈춤
          if (t === TILE.SOFT) {                              // 상자: 부수고 멈춤
            this.setTile(x, y, TILE.EMPTY);
            this.addFlame(x, y, until);
            if (this.rng() < RULES.ITEM_CHANCE) {
              spawnedItems.push([x, y, 1 + Math.floor(this.rng() * 3)]);
            }
            break;
          }
          const other = this.bombAt(x, y);
          if (other) {                                        // 다른 물풍선: 연쇄 폭발
            this.addFlame(x, y, until);
            queue.push(other);
            break;
          }
          this.items.delete(this.key(x, y));                  // 바닥 아이템은 물줄기에 사라짐
          this.addFlame(x, y, until);
        }
      }
    }
    // 연쇄가 끝난 뒤에 아이템 배치 (같은 폭발에 바로 지워지지 않도록)
    for (const [x, y, type] of spawnedItems) this.items.set(this.key(x, y), type);
  }

  addFlame(x, y, until) {
    const k = this.key(x, y);
    this.flames.set(k, Math.max(this.flames.get(k) || 0, until));
  }

  // ------------------------------------------------------------------
  // 한 틱 진행
  // ------------------------------------------------------------------
  step(dt) {
    if (this.over) return;
    this.time += dt * 1000;

    // 1) 이동
    for (const p of this.players.values()) this.movePlayer(p, dt);

    // 2) 물풍선 "통과 허용" 해제: 그 칸에서 완전히 벗어난 사람은 다시 못 들어감
    for (const b of this.bombs) {
      for (const id of b.passable) {
        const p = this.players.get(id);
        if (!p || Math.abs(p.x - b.x) >= 1 || Math.abs(p.y - b.y) >= 1) b.passable.delete(id);
      }
    }

    // 3) 시간이 된 물풍선 폭발
    for (const b of [...this.bombs]) {
      if (b.explodeAt <= this.time) this.explode(b);
    }

    // 4) 물줄기 만료
    for (const [k, until] of this.flames) if (until <= this.time) this.flames.delete(k);

    // 5) 피격 / 아이템 획득
    for (const p of this.players.values()) {
      if (p.status !== 'alive') continue;
      const k = this.key(Math.round(p.x), Math.round(p.y));
      if (this.flames.has(k)) {
        p.status = 'trapped';               // 크레이지 아케이드처럼 물방울에 갇힘
        p.trappedAt = this.time;
        continue;
      }
      const item = this.items.get(k);
      if (item) {
        const stat = ITEMS[item];           // 'bombs' | 'range' | 'speed'
        const field = stat === 'bombs' ? 'bombsMax' : stat;
        p[field] = Math.min(p[field] + 1, STAT_MAX[stat]);
        this.items.delete(k);
      }
    }

    // 6) 갇힌 플레이어: 시간이 지나거나 상대가 건드리면 탈락
    for (const p of this.players.values()) {
      if (p.status !== 'trapped') continue;
      if (this.time - p.trappedAt >= RULES.TRAP_MS) { p.status = 'dead'; p.dir = 0; continue; }
      for (const q of this.players.values()) {
        if (q === p || q.status !== 'alive') continue;
        if (Math.hypot(q.x - p.x, q.y - p.y) < RULES.POP_DISTANCE) { p.status = 'dead'; p.dir = 0; break; }
      }
    }

    // 7) 승패 판정
    const remaining = [...this.players.values()].filter(p => p.status !== 'dead');
    if (remaining.length <= 1) {
      // 남은 1명이 갇힌 상태여도 상대가 모두 탈락했으면 그 사람이 승리
      this.over = true;
      this.winner = remaining.length === 1 ? remaining[0].id : null;
    } else if (this.time >= RULES.ROUND_TIME_MS) {
      this.over = true;
      this.winner = null;                   // 시간 초과 → 무승부
    }
  }

  /** 플레이어가 나갔을 때 (연결 끊김 등) */
  removePlayer(id) {
    const p = this.players.get(id);
    if (p) { p.status = 'dead'; p.dir = 0; }
  }

  // ------------------------------------------------------------------
  // 클라이언트로 보낼 데이터
  // ------------------------------------------------------------------
  /** 라운드 시작 시 한 번: 전체 맵 */
  initialData() {
    return { w: this.w, h: this.h, tiles: Array.from(this.tiles) };
  }

  /** 매 틱: 움직이는 것들만 (소수점 2자리로 잘라 패킷 크기 절약) */
  snapshot() {
    const r2 = v => Math.round(v * 100) / 100;
    const snap = {
      t: 'state',
      left: Math.max(0, Math.ceil((RULES.ROUND_TIME_MS - this.time) / 1000)),
      p: [...this.players.values()].map(p => ({
        id: p.id, x: r2(p.x), y: r2(p.y), s: STATUS[p.status], d: p.dir,
        bm: p.bombsMax, rg: p.range, sp: p.speed,
      })),
      b: this.bombs.map(b => [b.x, b.y, Math.max(0, Math.round(b.explodeAt - this.time))]),
      f: [...this.flames.keys()].map(k => k.split(',').map(Number)),
      i: [...this.items].map(([k, v]) => [...k.split(',').map(Number), v]),
      tc: this.tileChanges,
    };
    this.tileChanges = [];                  // 보냈으니 비운다
    return snap;
  }
}

module.exports = { Game, DIRS, STATUS };
