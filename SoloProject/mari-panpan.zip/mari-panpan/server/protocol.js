/* =====================================================================
 * protocol.js — 클라이언트가 보낸 메시지 "검문소"
 * ---------------------------------------------------------------------
 * 보안의 첫 번째 원칙: 클라이언트가 보낸 건 전부 의심한다.
 * 여기서는
 *   1) JSON 파싱 실패 → 거부
 *   2) 알 수 없는 메시지 종류(t) → 거부
 *   3) 허용되지 않은 필드가 하나라도 있으면 → 거부 (예: x, y 를 몰래 보내기)
 *   4) 각 필드 타입·범위 검사
 *   5) 검사를 통과한 값만 "새 객체"에 옮겨 담아 반환
 *      → __proto__ 같은 키로 객체 프로토타입을 오염시키는 공격 차단
 * ===================================================================== */
'use strict';

const { CHARACTERS, MAPS } = require('../public/config.js');

// 방 코드에 쓰는 문자 (헷갈리는 0/O, 1/I/L 제외)
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const CODE_LENGTH = 5;
const CODE_RE = new RegExp('^[' + CODE_ALPHABET + ']{' + CODE_LENGTH + '}$');

const own = (obj, k) => Object.prototype.hasOwnProperty.call(obj, k);

// ------------------------------------------------------------------
// 필드별 검사 함수: 통과하면 "정리된 값", 실패하면 undefined 를 돌려준다
// ------------------------------------------------------------------
const V = {
  /** 닉네임: 제어문자·보이지 않는 문자·HTML 특수문자 제거 후 1~12글자 */
  name(v) {
    if (typeof v !== 'string' || v.length > 64) return undefined;
    const cleaned = v
      .normalize('NFC')
      // 제어문자, 줄바꿈, 폭 0 문자, 텍스트 방향 뒤집기 문자(RLO 등) 제거
      .replace(/[\u0000-\u001F\u007F-\u009F​-‏‪-‮⁠-⁩﻿]/g, '')
      // 화면에는 textContent 로만 넣지만, 혹시 모를 실수에 대비한 이중 방어
      .replace(/[<>&"'`]/g, '')
      .trim();
    const len = [...cleaned].length;        // 이모지·한글도 1글자로 세기
    return len >= 1 && len <= 12 ? cleaned : undefined;
  },
  code(v) { return typeof v === 'string' && CODE_RE.test(v) ? v : undefined; },
  char(v) { return typeof v === 'string' && own(CHARACTERS, v) ? v : undefined; },
  map(v)  { return typeof v === 'string' && own(MAPS, v) ? v : undefined; },
  bool(v) { return typeof v === 'boolean' ? v : undefined; },
  dir(v)  { return Number.isInteger(v) && v >= 0 && v <= 4 ? v : undefined; },
  ts(v)   { return typeof v === 'number' && Number.isFinite(v) ? v : undefined; },
};

// ------------------------------------------------------------------
// 메시지 종류별로 "허용되는 필드와 검사 함수" 목록 (화이트리스트)
// ------------------------------------------------------------------
const SCHEMA = {
  create: { name: V.name },
  join:   { code: V.code, name: V.name },
  pick:   { char: V.char },
  ready:  { v: V.bool },
  map:    { map: V.map },
  start:  {},
  input:  { d: V.dir },
  bomb:   {},
  leave:  {},
  ping:   { ts: V.ts },
};

/**
 * 원본 문자열 → { ok: true, msg } 또는 { ok: false, reason }
 */
function parseMessage(raw) {
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    return { ok: false, reason: 'bad_json' };
  }
  // 일반 객체 {} 만 허용 (배열, null, 숫자 등 거부)
  if (data === null || typeof data !== 'object' || Array.isArray(data)) {
    return { ok: false, reason: 'not_object' };
  }
  if (typeof data.t !== 'string' || !own(SCHEMA, data.t)) {
    return { ok: false, reason: 'unknown_type' };
  }
  const schema = SCHEMA[data.t];

  // 스키마에 없는 필드가 섞여 있으면 거부 (위치·스탯 위조 시도 등)
  for (const k of Object.keys(data)) {
    if (k !== 't' && !own(schema, k)) return { ok: false, reason: 'extra_field:' + k.slice(0, 20) };
  }

  // 검사 통과한 값만 프로토타입 없는 새 객체에 담는다
  const msg = Object.create(null);
  msg.t = data.t;
  for (const [k, check] of Object.entries(schema)) {
    if (!own(data, k)) return { ok: false, reason: 'missing:' + k };
    const val = check(data[k]);
    if (val === undefined) return { ok: false, reason: 'invalid:' + k };
    msg[k] = val;
  }
  return { ok: true, msg };
}

module.exports = { parseMessage, CODE_ALPHABET, CODE_LENGTH };
