/* =====================================================================
 * server.js — 웹 서버 + 웹소켓 게임 서버 (실행: npm start)
 * ---------------------------------------------------------------------
 * 구조를 최대한 단순하게:
 *   - 프로그램 하나(node)가 ① 게임 화면 파일(HTML/JS) 제공 ② 실시간 통신(WebSocket) 둘 다 한다.
 *   - 친구는 브라우저로 http://내IP:3000 에 접속하기만 하면 됨 (설치 필요 없음).
 *
 * 게임 판정 방식 = "권한형 서버(Authoritative Server)"
 *   - 클라이언트는 "어느 방향 키를 누르고 있는지", "물풍선 버튼을 눌렀는지"만 보낸다.
 *   - 위치·충돌·폭발·승패는 전부 서버가 계산해서 결과만 내려준다.
 *   → 클라이언트를 조작해도 순간이동·무적·스탯 조작이 불가능 (핵 방지의 기본)
 *
 * 보안 장치 요약 (각 위치에 [보안] 주석으로 표시)
 *   - 정적 파일은 화이트리스트로만 제공 (경로 조작 ../ 차단)
 *   - 보안 헤더(CSP 등)
 *   - Origin 검사 (다른 사이트가 몰래 접속하는 CSWSH 차단)
 *   - IP당 / 전체 접속 수 제한
 *   - 메시지 최대 크기 제한, 초당 메시지 수 제한(토큰 버킷)
 *   - 메시지 스키마 검증 (protocol.js)
 *   - 방장 권한 검사, 상태(대기/게임중) 검사
 *   - 응답 없는 연결 정리 (하트비트)
 * ===================================================================== */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const { MAPS, RULES } = require('../public/config.js');
const { Game } = require('./game.js');
const { parseMessage, CODE_ALPHABET, CODE_LENGTH } = require('./protocol.js');

// ------------------------------------------------------------------
// 설정값 (환경변수로 바꿀 수 있음)
// ------------------------------------------------------------------
const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';                 // 0.0.0.0 = 같은 공유기의 다른 PC에서도 접속 가능
// 허용 Origin 목록. 비워 두면 "요청한 Host 와 같은 Origin" 만 허용
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);

const LIMITS = {
  MAX_CONNECTIONS: 400,       // 서버 전체 동시 접속
  MAX_CONN_PER_IP: 6,         // IP 하나당 동시 접속 (창 여러 개 테스트 정도는 허용)
  MAX_ROOMS: 150,             // 방 개수
  MAX_PAYLOAD: 512,           // 메시지 1개 최대 바이트 (정상 메시지는 100바이트도 안 됨)
  RATE_CAPACITY: 30,          // 토큰 버킷 크기 (순간적으로 몰아 보낼 수 있는 양)
  RATE_REFILL_PER_SEC: 20,    // 초당 회복량 (= 평균 초당 허용 메시지 수)
  MAX_STRIKES: 25,            // 규칙 위반 누적 시 강제 종료 기준
  HEARTBEAT_MS: 10000,        // 이 주기로 살아 있는지 확인
  BAN_MS: Number(process.env.BAN_MS) || 60000,   // 규칙 위반으로 끊긴 IP 는 이 시간 동안 재접속 금지
};

// ==================================================================
// 1. HTTP 서버 — 게임 화면 파일 제공
// ==================================================================
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// [보안] 제공할 파일을 "목록"으로 고정. 요청 경로를 파일 경로로 그대로 쓰지 않으므로
//        /../../etc/passwd 같은 경로 조작(Path Traversal)이 원천적으로 불가능
const STATIC_FILES = {
  '/':           { file: 'index.html', type: 'text/html; charset=utf-8' },
  '/index.html': { file: 'index.html', type: 'text/html; charset=utf-8' },
  '/client.js':  { file: 'client.js',  type: 'text/javascript; charset=utf-8' },
  '/config.js':  { file: 'config.js',  type: 'text/javascript; charset=utf-8' },
  '/style.css':  { file: 'style.css',  type: 'text/css; charset=utf-8' },
};
// 캐릭터 그림(선택): public/assets/mari.png 처럼 영문 소문자 이름만 허용
const ASSET_RE = /^\/assets\/([a-z]{1,16})\.png$/;

// [보안] 모든 응답에 붙이는 보안 헤더
const SECURITY_HEADERS = {
  // 스크립트·스타일·이미지·접속 대상을 "우리 서버"로만 제한 → XSS 가 생겨도 피해 최소화
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; " +
    "connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
  'X-Content-Type-Options': 'nosniff',      // 브라우저가 파일 종류를 멋대로 추측하지 않게
  'X-Frame-Options': 'DENY',                // 다른 사이트 iframe 에 끼워 넣기 금지 (클릭재킹 방지)
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
};

const httpServer = http.createServer((req, res) => {
  // GET/HEAD 외에는 거부
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, SECURITY_HEADERS);
    return res.end();
  }
  // 쿼리스트링(?...) 은 무시하고 경로만 본다
  const urlPath = (req.url || '/').split('?')[0];

  let file, type;
  if (Object.prototype.hasOwnProperty.call(STATIC_FILES, urlPath)) {
    ({ file, type } = STATIC_FILES[urlPath]);
  } else {
    const m = ASSET_RE.exec(urlPath);
    if (m) { file = path.join('assets', m[1] + '.png'); type = 'image/png'; }
  }
  if (!file) {
    res.writeHead(404, { ...SECURITY_HEADERS, 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Not found');
  }

  fs.readFile(path.join(PUBLIC_DIR, file), (err, data) => {
    if (err) {
      res.writeHead(404, { ...SECURITY_HEADERS, 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Not found');
    }
    res.writeHead(200, { ...SECURITY_HEADERS, 'Content-Type': type });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
});

// ==================================================================
// 2. 웹소켓 서버 — 접속 단계 보안 검사
// ==================================================================
// noServer: 연결을 "수락하기 전에" 직접 검사하기 위해 upgrade 이벤트를 우리가 처리
const wss = new WebSocketServer({ noServer: true, maxPayload: LIMITS.MAX_PAYLOAD });
const connPerIp = new Map();   // IP → 현재 접속 수
// [보안] 강제 종료된 IP 의 재접속 금지 목록 (IP → 금지 해제 시각)
//        이게 없으면 끊겨도 바로 다시 접속해서 방 코드 대입·도배를 이어 갈 수 있다
const bannedUntil = new Map();

function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return false;   // 브라우저는 항상 Origin 을 보낸다. 없으면 거부
  if (ALLOWED_ORIGINS.length) return ALLOWED_ORIGINS.includes(origin);
  try {
    return new URL(origin).host === req.headers.host;   // 같은 주소에서 연 페이지만 허용
  } catch {
    return false;
  }
}

function rejectUpgrade(socket, code, text) {
  socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
  socket.destroy();
}

httpServer.on('upgrade', (req, socket, head) => {
  const ip = req.socket.remoteAddress || 'unknown';
  // [보안] 웹소켓 주소는 /ws 하나만
  if ((req.url || '').split('?')[0] !== '/ws') return rejectUpgrade(socket, 404, 'Not Found');
  // [보안] 다른 사이트의 페이지가 사용자 브라우저를 통해 몰래 접속하는 것(CSWSH) 차단
  if (!originAllowed(req)) return rejectUpgrade(socket, 403, 'Forbidden');
  // [보안] 접속 수 제한 (봇으로 연결만 수천 개 여는 공격 방어)
  if (wss.clients.size >= LIMITS.MAX_CONNECTIONS) return rejectUpgrade(socket, 503, 'Service Unavailable');
  if ((connPerIp.get(ip) || 0) >= LIMITS.MAX_CONN_PER_IP) return rejectUpgrade(socket, 429, 'Too Many Requests');
  if ((bannedUntil.get(ip) || 0) > Date.now()) return rejectUpgrade(socket, 429, 'Too Many Requests');

  wss.handleUpgrade(req, socket, head, ws => {
    connPerIp.set(ip, (connPerIp.get(ip) || 0) + 1);
    ws.ip = ip;
    onConnection(ws);
  });
});

// ==================================================================
// 3. 방(Room) 관리
// ==================================================================
const rooms = new Map();   // 방 코드 → Room

function newRoomCode() {
  // [보안] 예측 불가능한 난수(crypto)로 방 코드 생성 → 남의 방 코드 찍어 맞추기 어렵게
  for (let tries = 0; tries < 50; tries++) {
    let code = '';
    for (let i = 0; i < CODE_LENGTH; i++) code += CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)];
    if (!rooms.has(code)) return code;
  }
  return null;
}

class Room {
  constructor(code) {
    this.code = code;
    this.hostId = null;
    this.mapId = Object.keys(MAPS)[0];
    this.members = new Map();   // 플레이어 id → { id, name, char, ready, ws }
    this.state = 'lobby';       // 'lobby' | 'playing' | 'result'
    this.game = null;
    this.loop = null;
    this.resultTimer = null;
  }

  /** 대기방 정보 (모두에게 보낼 공개 정보만. ws 객체나 IP 는 절대 포함하지 않음) */
  publicInfo() {
    return {
      code: this.code,
      host: this.hostId,
      map: this.mapId,
      state: this.state,
      players: [...this.members.values()].map(m => ({ id: m.id, name: m.name, char: m.char, ready: m.ready })),
    };
  }

  broadcast(obj) {
    const data = JSON.stringify(obj);
    for (const m of this.members.values()) if (m.ws.readyState === 1) m.ws.send(data);
  }

  sendRoomInfo() { this.broadcast({ t: 'room', room: this.publicInfo() }); }

  // ---------------- 게임 시작 ----------------
  start() {
    const roster = [...this.members.values()].map(m => ({ id: m.id, char: m.char }));
    this.game = new Game(this.mapId, roster);
    this.state = 'playing';
    this.broadcast({ t: 'start', map: this.game.initialData(), players: this.publicInfo().players });

    // 고정 시간 간격으로 시뮬레이션 (setInterval 오차를 누적 시간으로 보정)
    const dt = 1 / RULES.TICK_RATE;
    let last = process.hrtime.bigint();
    let acc = 0;
    this.loop = setInterval(() => {
      const now = process.hrtime.bigint();
      acc += Number(now - last) / 1e9;
      last = now;
      let steps = 0;
      while (acc >= dt && steps < 5) { this.game.step(dt); acc -= dt; steps++; }
      if (steps === 5) acc = 0;           // 서버가 잠깐 멈췄다면 따라잡기 포기 (폭주 방지)
      this.broadcast(this.game.snapshot());
      if (this.game.over) this.finish();
    }, 1000 / RULES.TICK_RATE);
  }

  // ---------------- 게임 종료 → 결과 → 대기방 복귀 ----------------
  finish() {
    clearInterval(this.loop);
    this.loop = null;
    this.state = 'result';
    this.broadcast({ t: 'over', winner: this.game.winner });
    this.resultTimer = setTimeout(() => {
      this.resultTimer = null;
      this.game = null;
      this.state = 'lobby';
      for (const m of this.members.values()) m.ready = false;
      this.sendRoomInfo();
    }, RULES.RESULT_SHOW_MS);
  }

  /** 방 삭제 시 타이머 정리 (메모리 누수 방지) */
  dispose() {
    if (this.loop) clearInterval(this.loop);
    if (this.resultTimer) clearTimeout(this.resultTimer);
  }
}

// ==================================================================
// 4. 연결 하나하나 처리
// ==================================================================
function onConnection(ws) {
  ws.id = crypto.randomBytes(6).toString('hex');   // 플레이어 식별자 (서버가 정함)
  ws.room = null;
  ws.isAlive = true;
  ws.strikes = 0;                                   // 규칙 위반 점수
  ws.tokens = LIMITS.RATE_CAPACITY;                 // 토큰 버킷
  ws.lastRefill = Date.now();

  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (raw, isBinary) => {
    // [보안] 초당 메시지 수 제한 (토큰 버킷)
    const now = Date.now();
    ws.tokens = Math.min(LIMITS.RATE_CAPACITY, ws.tokens + ((now - ws.lastRefill) / 1000) * LIMITS.RATE_REFILL_PER_SEC);
    ws.lastRefill = now;
    if (ws.tokens < 1) return strike(ws, 'rate_limited');
    ws.tokens -= 1;

    // [보안] 바이너리 메시지는 쓰지 않으므로 거부
    if (isBinary) return strike(ws, 'binary');

    // [보안] 스키마 검증 (protocol.js)
    const parsed = parseMessage(raw.toString('utf8'));
    if (!parsed.ok) return strike(ws, parsed.reason);

    try {
      handle(ws, parsed.msg);
    } catch (err) {
      // 처리 중 예외가 나도 서버 전체가 죽지 않게. 내부 오류 내용은 클라이언트에 보내지 않음
      console.error('[handler error]', err);
      send(ws, { t: 'error', msg: '서버 오류' });
    }
  });

  ws.on('close', () => {
    leaveRoom(ws);
    const n = (connPerIp.get(ws.ip) || 1) - 1;
    if (n <= 0) connPerIp.delete(ws.ip); else connPerIp.set(ws.ip, n);
  });

  ws.on('error', () => {});   // 소켓 오류로 프로세스가 죽지 않도록

  send(ws, { t: 'hello', you: ws.id });
}

function send(ws, obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}

/** 규칙 위반 누적. 기준을 넘으면 연결을 끊는다 (1008 = 정책 위반) */
function strike(ws, reason) {
  ws.strikes++;
  if (ws.strikes === 1 || ws.strikes % 10 === 0) send(ws, { t: 'error', msg: '잘못된 요청', code: reason });
  if (ws.strikes >= LIMITS.MAX_STRIKES && ws.readyState === 1) {
    bannedUntil.set(ws.ip, Date.now() + LIMITS.BAN_MS);   // 잠시 재접속 금지
    ws.close(1008, 'policy');
  }
}

/** 화면에 띄울 오류 (규칙 위반은 아니지만 할 수 없는 행동) */
function deny(ws, msg) { send(ws, { t: 'error', msg }); }

// ------------------------------------------------------------------
// 메시지 종류별 처리 — 여기서는 "지금 이 행동을 할 자격이 있는가"를 검사
// ------------------------------------------------------------------
function handle(ws, msg) {
  const room = ws.room;
  const me = room ? room.members.get(ws.id) : null;

  switch (msg.t) {
    case 'ping':
      return send(ws, { t: 'pong', ts: msg.ts });

    case 'create': {
      if (room) return deny(ws, '이미 방에 들어가 있어요');
      if (rooms.size >= LIMITS.MAX_ROOMS) return deny(ws, '방이 너무 많아요. 잠시 후 다시 시도해 주세요');
      const code = newRoomCode();
      if (!code) return deny(ws, '방을 만들 수 없어요');
      const r = new Room(code);
      rooms.set(code, r);
      r.hostId = ws.id;
      r.members.set(ws.id, { id: ws.id, name: msg.name, char: 'mari', ready: false, ws });
      ws.room = r;
      return r.sendRoomInfo();
    }

    case 'join': {
      if (room) return deny(ws, '이미 방에 들어가 있어요');
      const r = rooms.get(msg.code);
      // 방이 없을 때와 꽉 찼을 때 메시지를 다르게 해도 되지만,
      // 코드 추측 공격에 힌트를 덜 주려고 "없음/입장 불가"는 같은 문구 사용
      if (!r || r.state !== 'lobby' || r.members.size >= RULES.MAX_PLAYERS) return deny(ws, '입장할 수 없는 방이에요');
      r.members.set(ws.id, { id: ws.id, name: msg.name, char: 'mari', ready: false, ws });
      ws.room = r;
      return r.sendRoomInfo();
    }

    case 'leave':
      return leaveRoom(ws);

    case 'pick':
      if (!room || room.state !== 'lobby') return deny(ws, '지금은 캐릭터를 바꿀 수 없어요');
      me.char = msg.char;
      me.ready = false;                       // 캐릭터를 바꾸면 준비 해제
      return room.sendRoomInfo();

    case 'ready':
      if (!room || room.state !== 'lobby') return;
      if (room.hostId === ws.id) return;      // 방장은 준비 대신 시작 버튼
      me.ready = msg.v;
      return room.sendRoomInfo();

    case 'map':
      if (!room || room.state !== 'lobby') return;
      if (room.hostId !== ws.id) return strike(ws, 'not_host');   // [보안] 방장만
      room.mapId = msg.map;
      return room.sendRoomInfo();

    case 'start': {
      if (!room || room.state !== 'lobby') return;
      if (room.hostId !== ws.id) return strike(ws, 'not_host');   // [보안] 방장만
      if (room.members.size < RULES.MIN_PLAYERS) return deny(ws, `${RULES.MIN_PLAYERS}명 이상 있어야 시작할 수 있어요`);
      const notReady = [...room.members.values()].some(m => m.id !== room.hostId && !m.ready);
      if (notReady) return deny(ws, '모두 준비를 눌러야 시작할 수 있어요');
      return room.start();
    }

    case 'input':
      // 게임 중이 아닐 때 오는 입력은 조용히 무시 (라운드 끝 직후 늦게 도착한 입력 등)
      if (room && room.state === 'playing') room.game.setInput(ws.id, msg.d);
      return;

    case 'bomb':
      if (room && room.state === 'playing') room.game.placeBomb(ws.id);
      return;
  }
}

function leaveRoom(ws) {
  const room = ws.room;
  if (!room) return;
  ws.room = null;
  room.members.delete(ws.id);
  if (room.game) room.game.removePlayer(ws.id);   // 게임 중 이탈 = 탈락 처리

  if (room.members.size === 0) {
    room.dispose();
    rooms.delete(room.code);
    return;
  }
  if (room.hostId === ws.id) room.hostId = room.members.keys().next().value;   // 다음 사람에게 방장 위임
  if (room.state === 'lobby') room.sendRoomInfo();
  else room.broadcast({ t: 'room', room: room.publicInfo() });
}

// ------------------------------------------------------------------
// [보안] 하트비트: 응답이 없는 "유령 연결"을 주기적으로 정리
// ------------------------------------------------------------------
const heartbeat = setInterval(() => {
  // 만료된 재접속 금지 기록 정리 (메모리가 계속 늘지 않게)
  const now = Date.now();
  for (const [ip, until] of bannedUntil) if (until <= now) bannedUntil.delete(ip);
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, LIMITS.HEARTBEAT_MS);
wss.on('close', () => clearInterval(heartbeat));

// ==================================================================
// 5. 실행
// ==================================================================
httpServer.listen(PORT, HOST, () => {
  console.log(`마리의 팡팡맨 서버 실행 중 → http://localhost:${PORT}`);
  console.log('같은 공유기의 다른 PC 에서는 http://<이 PC의 IP>:' + PORT + ' 로 접속');
});

module.exports = { httpServer, wss, rooms, LIMITS, bannedUntil };
