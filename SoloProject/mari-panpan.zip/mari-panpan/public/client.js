/* =====================================================================
 * client.js — 브라우저 쪽 코드
 * ---------------------------------------------------------------------
 * 하는 일은 딱 세 가지:
 *   1) 서버와 WebSocket 연결 유지
 *   2) 키보드 입력을 서버로 전달 (방향 / 물풍선)
 *   3) 서버가 보내 준 상태를 화면에 그리기
 * 게임 판정(충돌, 폭발, 승패)은 하나도 하지 않는다. 전부 서버 몫.
 *
 * [보안] 다른 사람이 입력한 닉네임은 절대 innerHTML 로 넣지 않고 textContent 로만 넣는다.
 *        → 닉네임에 <script> 를 넣어도 글자로만 보임 (XSS 방지)
 * ===================================================================== */
(() => {
  'use strict';

  const { CHARACTERS, MAPS, RULES, TILE } = window.GAME_CONFIG;
  const TS = 48;                                       // 화면상 타일 한 칸 크기(px)
  const $ = id => document.getElementById(id);

  // ------------------------------------------------------------------
  // 상태 저장소
  // ------------------------------------------------------------------
  const S = {
    ws: null,
    myId: null,
    room: null,        // 서버가 보낸 대기방 정보
    game: null,        // 진행 중인 게임 { w, h, tiles, names, prev, curr }
    retry: 0,          // 재연결 시도 횟수
  };

  // ==================================================================
  // 1. 서버 연결
  // ==================================================================
  function connect() {
    // 페이지를 연 주소 그대로 접속 (https 면 wss 로 자동 전환)
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/ws`);
    S.ws = ws;

    ws.onopen = () => {
      S.retry = 0;
      $('conn-status').textContent = '서버 연결됨';
    };
    ws.onmessage = ev => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      onMessage(msg);
    };
    ws.onclose = () => {
      // 연결이 끊기면 첫 화면으로 돌아가고 잠시 후 재연결
      S.room = null; S.game = null;
      showScreen('home');
      $('conn-status').textContent = '연결 끊김 — 다시 연결 중…';
      const wait = Math.min(5000, 500 * 2 ** S.retry++);   // 0.5s, 1s, 2s … 최대 5s
      setTimeout(connect, wait);
    };
  }

  function send(obj) {
    if (S.ws && S.ws.readyState === WebSocket.OPEN) S.ws.send(JSON.stringify(obj));
  }

  // 서버 메시지 분기
  function onMessage(msg) {
    switch (msg.t) {
      case 'hello': S.myId = msg.you; break;
      case 'room':  onRoom(msg.room); break;
      case 'start': onStart(msg); break;
      case 'state': onState(msg); break;
      case 'over':  onOver(msg); break;
      case 'error': toast(msg.msg || '오류'); break;
      case 'pong':  $('ping').textContent = `ping ${Math.round(performance.now() - msg.ts)}ms`; break;
    }
  }

  // 핑 측정 (네트워크 상태 확인용)
  setInterval(() => send({ t: 'ping', ts: performance.now() }), 2000);

  // ==================================================================
  // 2. 화면 전환 / 알림
  // ==================================================================
  function showScreen(name) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    $('screen-' + name).classList.add('active');
  }

  let toastTimer = null;
  function toast(text) {
    const el = $('toast');
    el.textContent = text;                 // textContent 사용 (서버 문구라도 HTML 로 해석하지 않음)
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
  }

  /** 요소 만들기 도우미: el('div', 'class', '텍스트') */
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  // ==================================================================
  // 3. 첫 화면
  // ==================================================================
  const nameInput = $('in-name');
  nameInput.value = sessionStorageSafeGet('name') || '';

  function getName() {
    const n = nameInput.value.trim();
    if (!n) { toast('닉네임을 입력해 주세요'); nameInput.focus(); return null; }
    sessionStorageSafeSet('name', n);
    return n;
  }

  $('btn-create').onclick = () => {
    const name = getName();
    if (name) send({ t: 'create', name });
  };
  $('btn-join').onclick = () => {
    const name = getName();
    const code = $('in-code').value.trim().toUpperCase();
    if (!name) return;
    if (code.length !== 5) return toast('방 코드 5자리를 입력해 주세요');
    send({ t: 'join', code, name });
  };
  $('in-code').addEventListener('keydown', e => { if (e.key === 'Enter') $('btn-join').click(); });

  // 저장소가 막힌 환경(시크릿 창 등)에서도 오류가 나지 않게 감싼다
  function sessionStorageSafeGet(k) { try { return sessionStorage.getItem(k); } catch { return null; } }
  function sessionStorageSafeSet(k, v) { try { sessionStorage.setItem(k, v); } catch { /* 무시 */ } }

  // ==================================================================
  // 4. 대기방
  // ==================================================================
  // 맵 선택 목록 채우기 (config.js 의 MAPS 기준)
  for (const [id, m] of Object.entries(MAPS)) {
    const opt = el('option', null, m.name);
    opt.value = id;
    $('sel-map').appendChild(opt);
  }
  $('sel-map').onchange = e => send({ t: 'map', map: e.target.value });

  // 캐릭터 카드 만들기 (한 번만)
  const charCards = {};
  for (const [id, c] of Object.entries(CHARACTERS)) {
    const card = el('button', 'char-card');
    const top = el('div', 'top');
    const dot = el('span', 'dot');
    dot.style.background = c.color;
    top.append(dot, el('span', null, c.name));
    card.appendChild(top);
    // 스탯 막대 3개
    for (const [label, key, max] of [['물풍선', 'bombs', 6], ['물줄기', 'range', 7], ['속도', 'speed', 6]]) {
      const row = el('div', 'stat');
      const bar = el('div', 'bar');
      const fill = el('i');
      fill.style.width = (c[key] / max) * 100 + '%';
      bar.appendChild(fill);
      row.append(el('span', null, `${label} ${c[key]}`), bar);
      card.appendChild(row);
    }
    card.onclick = () => send({ t: 'pick', char: id });
    charCards[id] = card;
    $('chars').appendChild(card);
  }

  $('btn-ready').onclick = () => {
    const me = S.room && S.room.players.find(p => p.id === S.myId);
    if (me) send({ t: 'ready', v: !me.ready });
  };
  $('btn-start').onclick = () => send({ t: 'start' });
  $('btn-leave').onclick = () => { send({ t: 'leave' }); S.room = null; showScreen('home'); };
  $('btn-copy').onclick = () => {
    if (!S.room) return;
    navigator.clipboard?.writeText(S.room.code).then(() => toast('방 코드를 복사했어요'), () => toast(S.room.code));
  };

  function onRoom(room) {
    S.room = room;
    if (room.state === 'lobby') {
      S.game = null;
      $('overlay').classList.remove('show');
      showScreen('lobby');
    }
    renderLobby();
    if (S.game) renderHud();
  }

  function renderLobby() {
    const room = S.room;
    if (!room) return;
    const isHost = room.host === S.myId;
    const me = room.players.find(p => p.id === S.myId);

    $('room-code').textContent = room.code;
    $('sel-map').value = room.map;
    $('sel-map').disabled = !isHost;                    // 맵은 방장만 변경

    // 참가자 자리
    const slots = $('slots');
    slots.replaceChildren();
    for (let i = 0; i < RULES.MAX_PLAYERS; i++) {
      const p = room.players[i];
      const slot = el('div', 'slot');
      if (!p) {
        slot.appendChild(el('div', 'empty', '빈 자리'));
      } else {
        const c = CHARACTERS[p.char];
        slot.classList.add('filled');
        if (p.id === S.myId) slot.classList.add('me');
        const av = el('div', 'avatar', c.name[0]);
        av.style.background = c.color;
        slot.append(av, el('div', 'pname', p.name), el('div', 'pchar', c.name));
        if (p.id === room.host) slot.appendChild(el('span', 'badge host', '방장'));
        else slot.appendChild(el('span', 'badge' + (p.ready ? ' ready' : ''), p.ready ? '준비 완료' : '대기 중'));
      }
      slots.appendChild(slot);
    }

    // 내가 고른 캐릭터 표시
    for (const [id, card] of Object.entries(charCards)) card.classList.toggle('picked', !!me && me.char === id);

    // 버튼 / 안내 문구
    $('btn-ready').style.display = isHost ? 'none' : '';
    $('btn-start').style.display = isHost ? '' : 'none';
    $('btn-ready').classList.toggle('on', !!me && me.ready);
    $('btn-ready').textContent = me && me.ready ? '준비 완료!' : '준비';

    const others = room.players.filter(p => p.id !== room.host);
    const allReady = others.length > 0 && others.every(p => p.ready);
    $('btn-start').disabled = !(room.players.length >= RULES.MIN_PLAYERS && allReady);
    $('lobby-hint').textContent =
      room.players.length < RULES.MIN_PLAYERS ? '상대를 기다리는 중… 방 코드를 친구에게 알려 주세요'
      : !allReady ? '모두 준비를 누르면 방장이 시작할 수 있어요'
      : isHost ? '시작할 수 있어요!' : '방장이 시작하길 기다리는 중…';
  }

  // ==================================================================
  // 5. 게임 시작 / 상태 수신
  // ==================================================================
  function onStart(msg) {
    const names = {};
    for (const p of msg.players) names[p.id] = { name: p.name, char: p.char };
    S.game = {
      w: msg.map.w, h: msg.map.h,
      tiles: Uint8Array.from(msg.map.tiles),
      names,
      prev: null, curr: null,       // 직전 / 최신 상태 (부드러운 이동을 위해 둘 사이를 보간)
    };
    const cv = $('canvas');
    cv.width = S.game.w * TS;
    cv.height = S.game.h * TS;
    $('overlay').classList.remove('show');
    showScreen('game');
    renderHud();
    held.length = 0;
    lastSentDir = -1;
    sendDir();
  }

  function onState(st) {
    const g = S.game;
    if (!g) return;
    // 바뀐 타일만 반영 (상자 파괴 등)
    for (const [x, y, v] of st.tc) g.tiles[y * g.w + x] = v;
    st.recvAt = performance.now();
    g.prev = g.curr || st;
    g.curr = st;
    $('timer').textContent = `${Math.floor(st.left / 60)}:${String(st.left % 60).padStart(2, '0')}`;
    renderHud();
  }

  function onOver(msg) {
    const g = S.game;
    const text = msg.winner == null ? '무승부!'
      : msg.winner === S.myId ? '승리! 🎉'
      : `${g?.names[msg.winner]?.name ?? '상대'} 승리`;
    $('overlay-text').textContent = text;
    $('overlay').classList.add('show');
  }

  // 왼쪽 정보창: 플레이어별 스탯
  function renderHud() {
    const g = S.game;
    if (!g) return;
    const box = $('hud-players');
    box.replaceChildren();
    const live = new Map((g.curr?.p || []).map(p => [p.id, p]));
    for (const [id, info] of Object.entries(g.names)) {
      const p = live.get(id);
      const c = CHARACTERS[info.char];
      const card = el('div', 'hud-p');
      if (id === S.myId) card.classList.add('me');
      if (!p || p.s === 2) card.classList.add('out');
      const n = el('div', 'n');
      const dot = el('i');
      dot.style.background = c.color;
      n.append(dot, el('span', null, `${info.name} (${c.name})`));
      const st = el('div', 'st', p
        ? `물풍선 ${p.bm} · 물줄기 ${p.rg} · 속도 ${p.sp}` + (p.s === 1 ? ' · 갇힘!' : p.s === 2 ? ' · 탈락' : '')
        : '나감');
      card.append(n, st);
      box.appendChild(card);
    }
  }

  // ==================================================================
  // 6. 키보드 입력
  //    여러 키를 동시에 누르면 "가장 마지막에 누른 방향"을 우선한다.
  //    방향이 바뀔 때만 서버로 보내서 메시지 수를 최소화 (초당 수십 개 보내지 않음).
  // ==================================================================
  const KEY_DIR = {
    ArrowUp: 1, KeyW: 1,
    ArrowDown: 2, KeyS: 2,
    ArrowLeft: 3, KeyA: 3,
    ArrowRight: 4, KeyD: 4,
  };
  const held = [];         // 누르고 있는 방향들 (누른 순서)
  let lastSentDir = -1;

  function sendDir() {
    const d = held.length ? held[held.length - 1] : 0;
    if (d !== lastSentDir) { lastSentDir = d; send({ t: 'input', d }); }
  }

  window.addEventListener('keydown', e => {
    if (!S.game) return;
    const d = KEY_DIR[e.code];
    if (d) {
      e.preventDefault();                  // 방향키로 페이지가 스크롤되지 않게
      if (!held.includes(d)) held.push(d);
      sendDir();
    } else if (e.code === 'Space') {
      e.preventDefault();
      if (!e.repeat) send({ t: 'bomb' });  // 꾹 눌러도 한 번만
    }
  });
  window.addEventListener('keyup', e => {
    const d = KEY_DIR[e.code];
    if (!d) return;
    const i = held.indexOf(d);
    if (i >= 0) held.splice(i, 1);
    if (S.game) sendDir();
  });
  // 창 밖을 클릭하면 keyup 을 못 받으므로 멈춤 처리
  window.addEventListener('blur', () => { held.length = 0; if (S.game) sendDir(); });

  // ==================================================================
  // 7. 그리기
  // ==================================================================
  const ctx = $('canvas').getContext('2d');

  // (선택) public/assets/<캐릭터id>.png 를 넣으면 원 대신 그림으로 표시
  const sprites = {};
  for (const [id, c] of Object.entries(CHARACTERS)) {
    if (!c.sprite) continue;                 // config.js 에서 sprite: true 인 캐릭터만 그림을 불러옴
    const img = new Image();
    img.src = `assets/${id}.png`;
    img.onerror = () => { sprites[id] = null; };
    sprites[id] = img;
  }
  const spriteReady = id => sprites[id] && sprites[id].complete && sprites[id].naturalWidth > 0;

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
  }

  function draw(now) {
    requestAnimationFrame(draw);
    const g = S.game;
    if (!g || !g.curr) return;

    // ---- 바닥 + 블록 ----
    for (let y = 0; y < g.h; y++) {
      for (let x = 0; x < g.w; x++) {
        const px = x * TS, py = y * TS;
        ctx.fillStyle = (x + y) % 2 ? '#e7f4dc' : '#def0d0';    // 체크무늬 잔디
        ctx.fillRect(px, py, TS, TS);
        const t = g.tiles[y * g.w + x];
        if (t === TILE.HARD) {
          ctx.fillStyle = '#9aa3c7';
          roundRect(px + 2, py + 2, TS - 4, TS - 4, 10); ctx.fill();
          ctx.fillStyle = '#b8bfdc';
          roundRect(px + 6, py + 5, TS - 12, TS - 18, 7); ctx.fill();
        } else if (t === TILE.SOFT) {
          ctx.fillStyle = '#e8b07f';
          roundRect(px + 4, py + 4, TS - 8, TS - 8, 8); ctx.fill();
          ctx.strokeStyle = '#c98a55'; ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(px + 10, py + 10); ctx.lineTo(px + TS - 10, py + TS - 10);
          ctx.moveTo(px + TS - 10, py + 10); ctx.lineTo(px + 10, py + TS - 10);
          ctx.stroke();
        }
      }
    }

    const st = g.curr;

    // ---- 아이템 ----
    const ITEM_LOOK = { 1: ['#5bb8ff', '풍'], 2: ['#7a6cf0', '줄'], 3: ['#3ccf91', '속'] };
    for (const [x, y, type] of st.i) {
      const [col, label] = ITEM_LOOK[type] || ['#999', '?'];
      const bob = Math.sin(now / 250 + x + y) * 2;               // 둥실둥실
      ctx.fillStyle = col;
      roundRect(x * TS + 10, y * TS + 10 + bob, TS - 20, TS - 20, 8); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 15px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(label, x * TS + TS / 2, y * TS + TS / 2 + bob + 1);
    }

    // ---- 물줄기 ----
    for (const [x, y] of st.f) {
      ctx.fillStyle = 'rgba(91, 184, 255, 0.75)';
      roundRect(x * TS + 3, y * TS + 3, TS - 6, TS - 6, 14); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.beginPath(); ctx.arc(x * TS + TS / 2, y * TS + TS / 2, TS / 5, 0, Math.PI * 2); ctx.fill();
    }

    // ---- 물풍선 (터질 때가 가까울수록 빨리 꿀렁임) ----
    for (const [x, y, left] of st.b) {
      const urgency = 1 - left / RULES.BOMB_FUSE_MS;
      const pulse = 1 + Math.sin(now / (120 - urgency * 80)) * 0.06;
      const r = TS * 0.36 * pulse;
      const cx = x * TS + TS / 2, cy = y * TS + TS / 2;
      ctx.fillStyle = '#4aa8f0';
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.7)';
      ctx.beginPath(); ctx.arc(cx - r * 0.35, cy - r * 0.35, r * 0.25, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2f7fc0';                                  // 매듭
      ctx.beginPath(); ctx.arc(cx, cy - r, 4, 0, Math.PI * 2); ctx.fill();
    }

    // ---- 플레이어 (직전 상태와 최신 상태 사이를 보간해서 부드럽게) ----
    const alpha = Math.min(1, (now - st.recvAt) / (1000 / RULES.TICK_RATE));
    const prevMap = new Map((g.prev?.p || []).map(p => [p.id, p]));
    for (const p of st.p) {
      if (p.s === 2) continue;                                    // 탈락자는 그리지 않음
      const q = prevMap.get(p.id) || p;
      const x = q.x + (p.x - q.x) * alpha;
      const y = q.y + (p.y - q.y) * alpha;
      const info = g.names[p.id];
      const c = CHARACTERS[info.char];
      const cx = x * TS + TS / 2, cy = y * TS + TS / 2;

      // 그림자
      ctx.fillStyle = 'rgba(0,0,0,.12)';
      ctx.beginPath(); ctx.ellipse(cx, cy + TS * 0.32, TS * 0.28, TS * 0.1, 0, 0, Math.PI * 2); ctx.fill();

      if (spriteReady(info.char)) {
        ctx.drawImage(sprites[info.char], cx - TS * 0.45, cy - TS * 0.55, TS * 0.9, TS * 0.9);
      } else {
        // 임시 캐릭터: 색 원 + 이름 첫 글자
        ctx.fillStyle = c.color;
        ctx.beginPath(); ctx.arc(cx, cy, TS * 0.34, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = p.id === S.myId ? '#ff3d84' : '#ffffff';
        ctx.lineWidth = 3; ctx.stroke();
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(c.name[0], cx, cy + 1);
      }

      // 갇힘: 큰 물방울 + 남은 시간 링
      if (p.s === 1) {
        ctx.fillStyle = 'rgba(160, 215, 255, .55)';
        ctx.beginPath(); ctx.arc(cx, cy, TS * 0.55, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 2; ctx.stroke();
      }

      // 닉네임 (fillText 는 글자로만 그리므로 XSS 와 무관)
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.lineWidth = 3; ctx.strokeStyle = '#fff';
      ctx.strokeText(info.name, cx, cy - TS * 0.42);
      ctx.fillStyle = '#3b3355';
      ctx.fillText(info.name, cx, cy - TS * 0.42);
    }
  }
  requestAnimationFrame(draw);

  connect();
})();
