/* =====================================================================
 * config.js — 서버와 클라이언트가 "같이" 쓰는 게임 설정 파일
 * ---------------------------------------------------------------------
 * - 브라우저에서는 <script src="config.js">로 읽혀서 window.GAME_CONFIG 가 되고
 * - Node.js 서버에서는 require('./public/config.js') 로 읽힌다.
 * 한 파일만 고치면 서버/클라이언트 수치가 동시에 바뀌도록 하기 위한 구조.
 * (실제 판정은 항상 서버가 하므로, 클라이언트가 이 파일을 조작해도
 *  게임 결과에는 영향이 없다. 클라이언트는 "표시용"으로만 쓴다.)
 * ===================================================================== */
(function (root) {
  'use strict';

  // ---------------------------------------------------------------
  // 1) 캐릭터 스탯
  //    bombs : 동시에 설치할 수 있는 물풍선 개수
  //    range : 물줄기 길이(칸 수)
  //    speed : 이동 속도 단계 (아래 speedToTilesPerSec 로 실제 속도로 변환)
  //    color : 아직 캐릭터 그림이 없어서 쓰는 임시 색상 (원 + 이름 표시)
  //    sprite: 캐릭터 그림을 쓰려면 true 로 바꾸고 public/assets/<캐릭터id>.png 를 넣는다
  //            (예: public/assets/mari.png). false 면 색 원으로 그린다.
  //
  //  ※ 요구사항 해석
  //    "기본 스탯은 대부분 2" → 속도 2, 범위 2 를 기본으로 두고,
  //    "마리는 폭탄 개수 2" 가 특징이 되려면 다른 캐릭터의 기본 폭탄 개수는 1 이어야
  //    차이가 생기므로 폭탄 기본값만 1 로 잡았다. 바꾸고 싶으면 여기 숫자만 수정.
  // ---------------------------------------------------------------
  const CHARACTERS = {
    mari:   { name: '마리',   bombs: 2, range: 2, speed: 2, color: '#f28fb0', sprite: false },
    butter: { name: '버터',   bombs: 1, range: 2, speed: 3, color: '#f2c94c', sprite: false },
    diana:  { name: '디아나', bombs: 1, range: 4, speed: 2, color: '#9b7be0', sprite: false },
    tig:    { name: '티그',   bombs: 1, range: 2, speed: 2, color: '#f2994a', sprite: false },
    komi:   { name: '코미',   bombs: 1, range: 2, speed: 2, color: '#56ccf2', sprite: false },
  };

  // 아이템으로 올릴 수 있는 최대치 (밸런스 상한)
  const STAT_MAX = { bombs: 6, range: 7, speed: 6 };

  // 속도 단계 → 초당 이동 칸 수. speed 2 = 초당 4칸, speed 3 = 초당 4.75칸
  function speedToTilesPerSec(speed) {
    return 2.5 + 0.75 * speed;
  }

  // ---------------------------------------------------------------
  // 2) 맵 정의 (문자열 격자)
  //    '#' : 부서지지 않는 블록
  //    '?' : 랜덤으로 상자(부서지는 블록)가 생길 수 있는 칸
  //    '.' : 항상 빈 칸
  //    '1'~'4' : 플레이어 시작 위치(주변은 '.' 로 비워 둬야 시작하자마자 갇히지 않음)
  //  나중에 맵을 추가할 때는 MAPS 에 항목만 더 넣으면 대기방 선택지에 자동으로 뜬다.
  // ---------------------------------------------------------------
  const MAPS = {
    village: {
      name: '기본 마을',
      softChance: 0.65, // '?' 칸에 상자가 생길 확률
      grid: [
        '1..???????????3',
        '.#?#?#?#?#?#?#.',
        '.?????????????.',
        '?#?#?#?#?#?#?#?',
        '???????????????',
        '?#?#?#?#?#?#?#?',
        '???????.???????',
        '?#?#?#?#?#?#?#?',
        '???????????????',
        '?#?#?#?#?#?#?#?',
        '.?????????????.',
        '.#?#?#?#?#?#?#.',
        '4..???????????2',
      ],
    },
  };

  // ---------------------------------------------------------------
  // 3) 게임 규칙 상수
  // ---------------------------------------------------------------
  const RULES = {
    MAX_PLAYERS: 4,          // 방 최대 인원 (2인 대전이 기본, 4인까지 허용)
    MIN_PLAYERS: 2,          // 시작에 필요한 최소 인원
    TICK_RATE: 30,           // 서버 시뮬레이션 초당 횟수
    BOMB_FUSE_MS: 2500,      // 물풍선이 터지기까지 시간
    FLAME_MS: 500,           // 물줄기가 남아 있는 시간
    TRAP_MS: 3000,           // 물방울에 갇혀 있는 시간 (이후 탈락)
    TRAP_SPEED: 0.6,         // 갇혔을 때 이동 속도(초당 칸)
    POP_DISTANCE: 0.6,       // 다른 플레이어가 이 거리 안에 오면 물방울이 터져 탈락
    ITEM_CHANCE: 0.35,       // 상자가 부서질 때 아이템이 나올 확률
    ROUND_TIME_MS: 180000,   // 라운드 제한 시간 (넘으면 무승부)
    RESULT_SHOW_MS: 5000,    // 결과 화면 후 대기방으로 돌아가기까지 시간
  };

  // 아이템 종류 — 서버/클라이언트 공통 번호
  const ITEMS = { 1: 'bombs', 2: 'range', 3: 'speed' };

  // 타일 종류 — 서버/클라이언트 공통 번호
  const TILE = { EMPTY: 0, HARD: 1, SOFT: 2 };

  const CONFIG = { CHARACTERS, STAT_MAX, MAPS, RULES, ITEMS, TILE, speedToTilesPerSec };

  // Node(서버)면 module.exports, 브라우저면 window 에 붙인다
  if (typeof module !== 'undefined' && module.exports) module.exports = CONFIG;
  else root.GAME_CONFIG = Object.freeze(CONFIG);
})(typeof window !== 'undefined' ? window : globalThis);
