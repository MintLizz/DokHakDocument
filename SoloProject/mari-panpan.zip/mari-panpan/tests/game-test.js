/* =====================================================================
 * game-test.js — 네트워크 없이 게임 규칙만 검사 (실행: npm run test:game)
 * 난수를 0.99 로 고정 → 상자·아이템이 하나도 안 생기는 "빈 맵"에서 테스트
 * ===================================================================== */
'use strict';
const assert = require('assert');
const { Game } = require('../server/game.js');
const { RULES, TILE } = require('../public/config.js');

const DT = 1 / RULES.TICK_RATE;
const noSoft = () => 0.99;
let passed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ✔', name); }
  catch (e) { console.log('  ✘', name, '\n    ', e.message); process.exitCode = 1; }
}
/** ms 만큼 시뮬레이션 진행 */
function run(g, ms) { for (let t = 0; t < ms; t += DT * 1000) g.step(DT); }

console.log('게임 규칙 테스트');

test('캐릭터 기본 스탯이 설정대로 들어간다', () => {
  const g = new Game('village', [{ id: 'a', char: 'mari' }, { id: 'b', char: 'diana' }], noSoft);
  const a = g.players.get('a'), b = g.players.get('b');
  assert.deepStrictEqual([a.bombsMax, a.range, a.speed], [2, 2, 2]);
  assert.deepStrictEqual([b.bombsMax, b.range, b.speed], [1, 4, 2]);
});

test('마리는 물풍선 2개, 버터는 1개까지만 설치된다', () => {
  const g = new Game('village', [{ id: 'm', char: 'mari' }, { id: 'b', char: 'butter' }], noSoft);
  const m = g.players.get('m');
  assert.ok(g.placeBomb('m'));
  m.x += 1;                                  // 옆 칸으로 옮겨서 하나 더
  assert.ok(g.placeBomb('m'));
  m.x += 1;
  assert.ok(!g.placeBomb('m'), '3번째는 거부돼야 함');
  assert.ok(g.placeBomb('b'));
  g.players.get('b').y -= 1;
  assert.ok(!g.placeBomb('b'), '버터 2번째는 거부돼야 함');
});

test('버터(속도3)가 마리(속도2)보다 같은 시간에 더 멀리 간다', () => {
  const g = new Game('village', [{ id: 'm', char: 'mari' }, { id: 'b', char: 'butter' }], noSoft);
  // 마리 (0,0) 아래로, 버터 (14,12) 위로 — 둘 다 세로 통로
  g.setInput('m', 2); g.setInput('b', 1);
  run(g, 500);
  const dm = g.players.get('m').y - 0, db = 12 - g.players.get('b').y;
  assert.ok(db > dm, `버터 ${db.toFixed(2)} > 마리 ${dm.toFixed(2)}`);
});

test('단단한 블록은 통과할 수 없다', () => {
  const g = new Game('village', [{ id: 'a', char: 'butter' }, { id: 'b', char: 'mari' }], noSoft);
  const a = g.players.get('a');
  a.x = 1; a.y = 0;                          // (1,1) 이 단단한 블록 → 아래로 못 감
  g.setInput('a', 2);
  run(g, 1000);
  assert.strictEqual(a.y, 0);
});

test('디아나 물줄기는 4칸, 마리는 2칸', () => {
  const g = new Game('village', [{ id: 'd', char: 'diana' }, { id: 'm', char: 'mari' }], noSoft);
  const d = g.players.get('d');
  d.x = 0; d.y = 2;                          // 2번째 줄은 가로로 쭉 뚫린 길
  g.placeBomb('d');
  d.x = 7; d.y = 6;                          // 폭발 범위 밖으로 피신 (테스트용 순간이동)
  run(g, RULES.BOMB_FUSE_MS + 50);
  assert.ok(g.flames.has('4,2'), '4칸째 물줄기 있어야 함');
  assert.ok(!g.flames.has('5,2'), '5칸째는 없어야 함');
});

test('물줄기에 맞으면 갇히고, 시간이 지나면 탈락 → 상대 승리', () => {
  const g = new Game('village', [{ id: 'a', char: 'mari' }, { id: 'b', char: 'komi' }], noSoft);
  g.placeBomb('a');                          // 자기 발밑에 설치하고 가만히 있음
  run(g, RULES.BOMB_FUSE_MS + 50);
  assert.strictEqual(g.players.get('a').status, 'trapped');
  run(g, RULES.TRAP_MS + 50);
  assert.strictEqual(g.players.get('a').status, 'dead');
  assert.ok(g.over);
  assert.strictEqual(g.winner, 'b');
});

test('갇힌 상대를 건드리면 바로 터진다', () => {
  const g = new Game('village', [{ id: 'a', char: 'mari' }, { id: 'b', char: 'tig' }], noSoft);
  const a = g.players.get('a'), b = g.players.get('b');
  a.status = 'trapped'; a.trappedAt = 0;
  b.x = a.x + 0.3; b.y = a.y;
  g.step(DT);
  assert.strictEqual(a.status, 'dead');
  assert.strictEqual(g.winner, 'b');
});

test('물풍선 연쇄 폭발', () => {
  const g = new Game('village', [{ id: 'a', char: 'mari' }, { id: 'b', char: 'tig' }], noSoft);
  const a = g.players.get('a');
  a.x = 0; a.y = 2; g.placeBomb('a');        // 첫 번째 (0,2)
  run(g, 1000);
  a.x = 2; a.y = 2; g.placeBomb('a');        // 두 번째 (2,2), 1초 늦게
  a.x = 7; a.y = 6;
  run(g, RULES.BOMB_FUSE_MS - 1000 + 50);   // 첫 번째만 터질 시간
  assert.strictEqual(g.bombs.length, 0, '두 번째도 같이 터져야 함');
});

test('설치 직후 자기 물풍선 위에서는 빠져나갈 수 있지만, 나간 뒤엔 다시 못 들어온다', () => {
  const g = new Game('village', [{ id: 'a', char: 'mari' }, { id: 'b', char: 'tig' }], noSoft);
  const a = g.players.get('a');
  a.x = 3; a.y = 2;
  g.placeBomb('a');
  g.setInput('a', 4); run(g, 400);           // 오른쪽으로 빠져나감
  assert.ok(a.x > 3.9);
  g.setInput('a', 3); run(g, 400);           // 다시 왼쪽으로 → 물풍선에 막힘
  assert.ok(a.x >= 4 - 1e-9, `x=${a.x}`);
});

test('상자를 부수면 아이템이 나오고, 먹으면 스탯이 오른다', () => {
  // 난수: 상자 생성 0.0(생성됨), 아이템 확률 0.0(나옴), 종류 0.0(물풍선)
  const g = new Game('village', [{ id: 'a', char: 'tig' }, { id: 'b', char: 'mari' }], () => 0);
  const a = g.players.get('a');
  // (1,0) (2,0) 은 '.' 이라 비어 있고 (3,0) 은 상자
  a.x = 2; a.y = 0; g.placeBomb('a');
  a.x = 0; a.y = 2;                          // 피신
  run(g, RULES.BOMB_FUSE_MS + RULES.FLAME_MS + 50);
  assert.strictEqual(g.tileAt(3, 0), TILE.EMPTY);
  assert.strictEqual(g.items.get('3,0'), 1);
  a.x = 3; a.y = 0; g.step(DT);
  assert.strictEqual(a.bombsMax, 2);
});

console.log(`\n${passed}개 통과`);
