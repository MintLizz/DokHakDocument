/* =====================================================================
 * security-test.js — "공격자 입장"에서 서버를 두드려 보는 보안 테스트
 * ---------------------------------------------------------------------
 * 실행 방법: 서버를 켜 둔 상태에서 (npm start)  다른 터미널에서  npm run test:security
 *           다른 주소를 테스트하려면: TARGET=http://192.168.0.10:3000 npm run test:security
 *           빠르게 돌리려면: 서버를 BAN_MS=5000 npm start 로 켜고  BAN_WAIT_MS=5500 npm run test:security
 *
 * 각 항목은 "공격 시도 → 서버가 막았는지" 를 확인한다.
 *   ✔ = 막힘(정상)   ✘ = 뚫림(고쳐야 함)
 *
 * ⚠ 자기 서버에만 실행할 것. 남의 서버에 돌리면 공격 행위가 된다.
 * ===================================================================== */
'use strict';
const http = require('http');
const WebSocket = require('ws');

const TARGET = new URL(process.env.TARGET || 'http://localhost:3000');
const WS_URL = `ws://${TARGET.host}/ws`;
const GOOD_ORIGIN = TARGET.origin;
const sleep = ms => new Promise(r => setTimeout(r, ms));
// 서버의 재접속 금지 시간(BAN_MS)보다 조금 길게 기다려야 다음 테스트가 접속 가능
const BAN_WAIT = Number(process.env.BAN_WAIT_MS) || 61000;

const results = [];
async function test(category, name, fn) {
  try {
    const detail = await fn();
    results.push({ category, name, ok: true, detail });
    console.log(`  ✔ [${category}] ${name}${detail ? ' — ' + detail : ''}`);
  } catch (e) {
    results.push({ category, name, ok: false, detail: e.message });
    console.log(`  ✘ [${category}] ${name} — ${e.message}`);
  }
  await sleep(150);   // 앞 테스트의 연결이 정리될 시간
}
function expect(cond, msg) { if (!cond) throw new Error(msg); }

// ------------------------------------------------------------------
// HTTP 요청 도우미 (경로를 가공하지 않고 그대로 보냄 — 경로 조작 테스트용)
// ------------------------------------------------------------------
function rawGet(pathname, method = 'GET') {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: TARGET.hostname, port: TARGET.port, path: pathname, method }, res => {
      let body = '';
      res.on('data', c => (body += c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body }));
    });
    req.on('error', reject);
    req.end();
  });
}

// ------------------------------------------------------------------
// 웹소켓 클라이언트 도우미
// ------------------------------------------------------------------
function connect({ origin = GOOD_ORIGIN, url = WS_URL } = {}) {
  return new Promise((resolve, reject) => {
    const headers = origin ? { Origin: origin } : {};
    const ws = new WebSocket(url, { headers });
    const c = { ws, msgs: [], closed: null, waiters: [] };
    ws.on('message', d => {
      const m = JSON.parse(d.toString());
      c.msgs.push(m);
      c.waiters = c.waiters.filter(w => (w.pred(m) ? (w.resolve(m), false) : true));
    });
    ws.on('close', code => { c.closed = code; });
    ws.on('unexpected-response', (req, res) => reject(new Error('HTTP ' + res.statusCode)));
    ws.on('error', reject);
    ws.on('open', () => {
      c.send = obj => ws.send(typeof obj === 'string' ? obj : JSON.stringify(obj));
      // 조건에 맞는 메시지를 기다림 (이미 받은 것도 포함)
      c.wait = (pred, ms = 1500) => new Promise((res, rej) => {
        const found = c.msgs.find(pred);
        if (found) return res(found);
        const w = { pred, resolve: res };
        c.waiters.push(w);
        setTimeout(() => rej(new Error('응답 없음(타임아웃)')), ms);
      });
      c.close = () => ws.close();
      resolve(c);
    });
  });
}

/** 방 하나 만들어서 [방장, 참가자] 반환 */
async function makeRoom(hostChar = 'mari', guestChar = 'butter') {
  const a = await connect(), b = await connect();
  a.send({ t: 'create', name: '방장' });
  const room = (await a.wait(m => m.t === 'room')).room;
  b.send({ t: 'join', code: room.code, name: '손님' });
  await b.wait(m => m.t === 'room');
  a.send({ t: 'pick', char: hostChar });
  b.send({ t: 'pick', char: guestChar });
  await sleep(100);
  return { a, b, code: room.code };
}

// ==================================================================
(async () => {
  console.log(`보안 테스트 대상: ${TARGET.origin}\n`);

  // ---------------------------------------------------------------- HTTP
  await test('HTTP', '경로 조작(Path Traversal)으로 서버 소스 읽기', async () => {
    const paths = ['/../server/server.js', '/%2e%2e/server/server.js', '/assets/../../server/server.js',
                   '/assets/..%2f..%2fpackage.json', '/..%5cpackage.json', '/package.json', '/server/server.js'];
    for (const p of paths) {
      const r = await rawGet(p);
      expect(r.status === 404, `${p} → ${r.status}`);
      expect(!r.body.includes('require('), `${p} 에서 소스 노출`);
    }
    return `${paths.length}개 경로 모두 404`;
  });

  await test('HTTP', '보안 헤더(CSP, nosniff, X-Frame-Options) 존재', async () => {
    const r = await rawGet('/');
    expect(r.headers['content-security-policy']?.includes("script-src 'self'"), 'CSP 없음');
    expect(r.headers['x-content-type-options'] === 'nosniff', 'nosniff 없음');
    expect(r.headers['x-frame-options'] === 'DENY', 'X-Frame-Options 없음');
    expect(!r.headers['x-powered-by'], '서버 정보 노출');
  });

  await test('HTTP', 'GET 외 메서드(POST/PUT/DELETE) 거부', async () => {
    for (const m of ['POST', 'PUT', 'DELETE']) expect((await rawGet('/', m)).status === 405, m + ' 허용됨');
  });

  // ---------------------------------------------------------------- 접속 단계
  await test('접속', 'Origin 없이 접속 (스크립트/봇)', async () => {
    try { await connect({ origin: null }); } catch (e) { return '거부: ' + e.message; }
    throw new Error('접속 허용됨');
  });

  await test('접속', '다른 사이트 Origin 으로 접속 (CSWSH)', async () => {
    try { await connect({ origin: 'https://evil.example' }); } catch (e) { return '거부: ' + e.message; }
    throw new Error('접속 허용됨');
  });

  await test('접속', '정해지지 않은 경로(/admin)로 웹소켓 접속', async () => {
    try { await connect({ url: `ws://${TARGET.host}/admin` }); } catch (e) { return '거부: ' + e.message; }
    throw new Error('접속 허용됨');
  });

  await test('접속', '한 IP 에서 연결 대량 생성', async () => {
    const conns = [];
    let rejectedAt = null;
    for (let i = 1; i <= 20; i++) {
      try { conns.push(await connect()); } catch { rejectedAt = i; break; }
    }
    conns.forEach(c => c.close());
    await sleep(300);
    expect(rejectedAt !== null, '20개 모두 허용됨');
    return `${rejectedAt}번째 연결부터 거부 (429)`;
  });

  // ---------------------------------------------------------------- 메시지 위조
  await test('메시지', '깨진 JSON 전송 → 거부, 서버는 계속 동작', async () => {
    const c = await connect();
    c.send('{"t":"create",');
    const err = await c.wait(m => m.t === 'error');
    c.send({ t: 'ping', ts: 1 });
    await c.wait(m => m.t === 'pong');
    c.close();
    return 'code=' + err.code;
  });

  await test('메시지', '큰 메시지(4KB) 전송 → 연결 차단', async () => {
    const c = await connect();
    c.send(JSON.stringify({ t: 'create', name: 'x'.repeat(4000) }));
    await sleep(300);
    expect(c.closed !== null, '연결 유지됨');
    return 'close code ' + c.closed + ' (1009 = 메시지 너무 큼)';
  });

  await test('메시지', '위치 좌표 위조 {t:"input", d:1, x:7, y:6}', async () => {
    const c = await connect();
    c.send({ t: 'input', d: 1, x: 7, y: 6 });
    const err = await c.wait(m => m.t === 'error');
    c.close();
    expect(err.code.startsWith('extra_field'), err.code);
    return 'code=' + err.code;
  });

  await test('메시지', '스탯 위조 {t:"pick", char:"mari", bombs:99, speed:99}', async () => {
    const c = await connect();
    c.send({ t: 'pick', char: 'mari', bombs: 99, speed: 99 });
    const err = await c.wait(m => m.t === 'error');
    c.close();
    return 'code=' + err.code;
  });

  await test('메시지', '타입/범위 위반 (없는 캐릭터, d=99, d=1.5, v="yes")', async () => {
    const c = await connect();
    const bad = [{ t: 'pick', char: 'admin' }, { t: 'input', d: 99 }, { t: 'input', d: 1.5 },
                 { t: 'ready', v: 'yes' }, { t: 'pick', char: 'constructor' }, { t: 'map', map: '__proto__' }, [1, 2], null, 42];
    let errors = 0;
    for (const b of bad) { c.send(JSON.stringify(b)); }
    await sleep(300);
    errors = c.msgs.filter(m => m.t === 'error').length;
    c.close();
    expect(errors >= 1, '오류 응답 없음');
    return `${bad.length}건 모두 거부 (오류 알림은 묶어서 ${errors}회)`;
  });

  await test('메시지', '프로토타입 오염 {"__proto__":{"isAdmin":true}}', async () => {
    const c = await connect();
    c.send('{"t":"create","name":"해커","__proto__":{"isAdmin":true}}');
    const err = await c.wait(m => m.t === 'error');
    c.send('{"t":"create","name":"해커","constructor":{"prototype":{"x":1}}}');
    await sleep(100);
    c.close();
    return 'code=' + err.code;
  });

  // ---------------------------------------------------------------- 닉네임
  await test('닉네임', 'XSS 닉네임 <script>…</script> 정리', async () => {
    const c = await connect();
    c.send({ t: 'create', name: '<b>a</b>"\'`&' });
    const r = await c.wait(m => m.t === 'room');
    c.close();
    const name = r.room.players[0].name;
    expect(!/[<>"'`&]/.test(name), '특수문자 남음: ' + name);
    return `"${name}" 로 저장`;
  });

  await test('닉네임', '보이지 않는 문자/방향 뒤집기(RLO)/너무 긴 이름', async () => {
    const c = await connect();
    c.send({ t: 'create', name: '​‮\u0000' });   // 정리하면 빈 이름 → 거부
    const e1 = await c.wait(m => m.t === 'error');
    c.send({ t: 'create', name: '가'.repeat(13) });          // 13글자 → 거부
    await sleep(100);
    c.close();
    return 'code=' + e1.code;
  });

  // ---------------------------------------------------------------- 권한
  await test('권한', '방장이 아닌 사람이 게임 시작 / 맵 변경', async () => {
    const { a, b } = await makeRoom();
    b.send({ t: 'ready', v: true });
    await sleep(100);
    b.send({ t: 'start' });
    b.send({ t: 'map', map: 'village' });
    await sleep(300);
    const started = [...a.msgs, ...b.msgs].some(m => m.t === 'start');
    const err = b.msgs.find(m => m.t === 'error');
    a.close(); b.close();
    expect(!started, '게임이 시작됨!');
    return '거부 code=' + err?.code;
  });

  await test('권한', '상대가 준비 안 했는데 방장이 강제 시작', async () => {
    const { a, b } = await makeRoom();
    a.send({ t: 'start' });
    await sleep(300);
    const started = a.msgs.some(m => m.t === 'start');
    a.close(); b.close();
    expect(!started, '게임이 시작됨!');
  });

  await test('권한', '게임 진행 중인 방에 난입', async () => {
    const { a, b, code } = await makeRoom();
    b.send({ t: 'ready', v: true }); await sleep(100);
    a.send({ t: 'start' });
    await a.wait(m => m.t === 'start');
    const c = await connect();
    c.send({ t: 'join', code, name: '난입' });
    const err = await c.wait(m => m.t === 'error');
    [a, b, c].forEach(x => x.close());
    return `"${err.msg}"`;
  });

  // ---------------------------------------------------------------- 게임 내 치트
  await test('치트', '물풍선 연타로 개수 제한 넘기 (마리 최대 2개)', async () => {
    const { a, b } = await makeRoom('mari', 'butter');
    b.send({ t: 'ready', v: true }); await sleep(100);
    a.send({ t: 'start' });
    await a.wait(m => m.t === 'start');
    // 오른쪽으로 걸으면서 물풍선 버튼 연타
    a.send({ t: 'input', d: 4 });
    for (let i = 0; i < 15; i++) { a.send({ t: 'bomb' }); await sleep(40); }
    await sleep(100);
    const maxBombs = Math.max(...a.msgs.filter(m => m.t === 'state').map(s => s.b.length));
    a.close(); b.close();
    expect(maxBombs <= 2, `물풍선 ${maxBombs}개 설치됨`);
    return `15번 눌렀지만 최대 ${maxBombs}개`;
  });

  await test('치트', '입력 연타로 이동 속도 올리기 (스피드핵)', async () => {
    const { a, b } = await makeRoom('mari', 'butter');
    b.send({ t: 'ready', v: true }); await sleep(100);
    a.send({ t: 'start' });
    await a.wait(m => m.t === 'start');
    const startState = await a.wait(m => m.t === 'state');
    const y0 = startState.p.find(p => p.id === startState.p[0].id).y;
    const t0 = Date.now();
    // 아래 방향을 초당 ~15회 반복 전송 (속도 제한 안쪽으로)
    for (let i = 0; i < 10; i++) { a.send({ t: 'input', d: 2 }); await sleep(66); }
    const states = a.msgs.filter(m => m.t === 'state');
    const last = states[states.length - 1];
    const dy = last.p[0].y - y0;
    const sec = (Date.now() - t0) / 1000;
    a.close(); b.close();
    const maxAllowed = (2.5 + 0.75 * 2) * sec + 0.3;   // 속도2 = 초당 4칸 (+오차)
    expect(dy <= maxAllowed, `${dy.toFixed(2)}칸 이동 (허용 ${maxAllowed.toFixed(2)})`);
    return `${sec.toFixed(2)}초 동안 ${dy.toFixed(2)}칸 = 정상 속도`;
  });

  // ---------------------------------------------------------------- 정보 노출
  await test('정보노출', '방 정보에 IP·내부 객체가 섞여 나가는지', async () => {
    const { a, b } = await makeRoom();
    const r = a.msgs.filter(m => m.t === 'room').pop().room;
    a.close(); b.close();
    const keys = new Set(r.players.flatMap(p => Object.keys(p)));
    expect([...keys].every(k => ['id', 'name', 'char', 'ready'].includes(k)), '추가 필드: ' + [...keys]);
    expect(!JSON.stringify(r).includes('127.0.0.1') && !JSON.stringify(r).includes('::'), 'IP 노출');
    return '공개 필드: ' + [...keys].join(', ');
  });

  await test('정보노출', '서버 오류 메시지에 내부 정보(스택 등) 노출', async () => {
    const c = await connect();
    c.send('{"t":"join","code":"AAAAA","name":"x"}');
    const err = await c.wait(m => m.t === 'error');
    c.close();
    expect(!/at |\.js|Error/.test(err.msg), '내부 정보 노출: ' + err.msg);
    return `"${err.msg}"`;
  });

  // ---------------------------------------------------------------- 도배 / 대입 (연결이 강제로 끊기는 테스트라 맨 뒤에)
  await test('권한', '방 코드 무작위 대입(브루트포스)', async () => {
    const c = await connect();
    const AL = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    let sent = 0;
    for (let i = 0; i < 300 && c.closed === null; i++) {
      let code = '';
      for (let k = 0; k < 5; k++) code += AL[Math.floor(Math.random() * AL.length)];
      c.send({ t: 'join', code, name: '봇' });
      sent++;
      await sleep(1);
    }
    await sleep(300);
    const joined = c.msgs.some(m => m.t === 'room');
    expect(!joined, '우연히 입장됨');
    expect(c.closed !== null, '300번 시도 동안 차단 안 됨');
    const total = AL.length ** 5;
    return `${sent}번 시도 후 연결 차단. 코드 경우의 수 ${total.toLocaleString()}개`;
  });


  await test('도배', '강제 종료된 직후 바로 재접속해서 공격 이어 가기', async () => {
    try { await connect(); } catch (e) { return '재접속 거부: ' + e.message + ' (일정 시간 재접속 금지)'; }
    throw new Error('바로 재접속됨');
  });


  // 재접속 금지 시간이 지나기를 기다림 (서버를 BAN_MS=5000 으로 켜고 BAN_WAIT_MS=5500 을 주면 빨라짐)
  console.log(`  … 재접속 금지 해제 대기 ${BAN_WAIT / 1000}초`);
  await sleep(BAN_WAIT);

  await test('도배', '메시지 1000개 연속 전송(플러딩)', async () => {
    const c = await connect();
    for (let i = 0; i < 1000 && c.ws.readyState === 1; i++) c.send({ t: 'ping', ts: i });
    await sleep(500);
    const pongs = c.msgs.filter(m => m.t === 'pong').length;
    expect(c.closed === 1008, '연결 유지됨 (close=' + c.closed + ')');
    return `처리된 것 ${pongs}개, 나머지 버림 → 연결 종료(1008)`;
  });


  // ---------------------------------------------------------------- 요약
  const failed = results.filter(r => !r.ok);
  console.log(`\n결과: ${results.length - failed.length}/${results.length} 방어 성공`);
  if (failed.length) { console.log('뚫린 항목:'); failed.forEach(f => console.log(' -', f.name)); process.exitCode = 1; }
  require('fs').writeFileSync(require('path').join(__dirname, 'security-report.json'), JSON.stringify(results, null, 2));
  setTimeout(() => process.exit(), 200);
})();
